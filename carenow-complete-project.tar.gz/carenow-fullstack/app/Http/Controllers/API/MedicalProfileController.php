<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\MedicalProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MedicalProfileController extends Controller
{
    public function myProfile(Request $request)
    {
        $profile = $request->user()->medicalProfile;
        if (!$profile) {
            return response()->json(['success' => false, 'message' => 'Medical profile not found'], 404);
        }
        return response()->json(['success' => true, 'data' => $profile]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'blood_type' => 'required|in:A+,A-,B+,B-,AB+,AB-,O+,O-',
            'date_of_birth' => 'required|date',
            'gender' => 'required|in:male,female',
            'emergency_contact_name' => 'required|string',
            'emergency_contact_phone' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'errors' => $validator->errors()], 422);
        }

        $profile = MedicalProfile::updateOrCreate(
            ['user_id' => $request->user()->id],
            $request->all()
        );

        return response()->json(['success' => true, 'message' => 'Medical profile saved successfully', 'data' => $profile], 201);
    }

    public function show($id)
    {
        $profile = MedicalProfile::findOrFail($id);
        return response()->json(['success' => true, 'data' => $profile]);
    }

}
