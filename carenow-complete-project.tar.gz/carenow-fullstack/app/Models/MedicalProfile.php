<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MedicalProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'blood_type',
        'date_of_birth',
        'gender',
        'height',
        'weight',
        'chronic_diseases',
        'allergies',
        'current_medications',
        'emergency_contact_name',
        'emergency_contact_phone',
        'insurance_number',
        'insurance_provider',
    ];

    protected $casts = [
        'chronic_diseases' => 'array',
        'allergies' => 'array',
        'current_medications' => 'array',
        'date_of_birth' => 'date',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
