<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Doctor extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'specialization',
        'license_number',
        'years_of_experience',
        'clinic_address',
        'consultation_fee',
        'available_days',
        'available_hours',
        'bio',
        'is_verified',
        'rating',
    ];

    protected $casts = [
        'available_days' => 'array',
        'available_hours' => 'array',
        'is_verified' => 'boolean',
        'consultation_fee' => 'decimal:2',
        'rating' => 'decimal:2',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function consultations()
    {
        return $this->hasMany(Consultation::class);
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }
}
