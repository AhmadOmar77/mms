<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ambulance extends Model
{
    use HasFactory;

    protected $fillable = [
        'vehicle_number',
        'driver_id',
        'current_latitude',
        'current_longitude',
        'status',
        'vehicle_type',
        'equipment_list',
    ];

    protected $casts = [
        'current_latitude' => 'decimal:8',
        'current_longitude' => 'decimal:8',
        'equipment_list' => 'array',
    ];

    public function driver()
    {
        return $this->belongsTo(User::class, 'driver_id');
    }

    public function emergencyAlerts()
    {
        return $this->hasMany(EmergencyAlert::class);
    }
}
