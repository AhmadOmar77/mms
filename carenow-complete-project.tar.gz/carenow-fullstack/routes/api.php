<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\MedicalProfileController;
use App\Http\Controllers\API\DoctorController;
use App\Http\Controllers\API\EmergencyAlertController;
use App\Http\Controllers\API\ConsultationController;
use App\Http\Controllers\API\AmbulanceController;

// Public routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {
    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    
    // Medical Profile routes
    Route::apiResource('medical-profiles', MedicalProfileController::class);
    Route::get('/my-profile', [MedicalProfileController::class, 'myProfile']);
    
    // Doctor routes
    Route::apiResource('doctors', DoctorController::class);
    Route::get('/doctors-available', [DoctorController::class, 'available']);
    
    // Emergency Alert routes
    Route::apiResource('emergency-alerts', EmergencyAlertController::class);
    Route::post('/emergency-alerts/{id}/dispatch', [EmergencyAlertController::class, 'dispatch']);
    
    // Consultation routes
    Route::apiResource('consultations', ConsultationController::class);
    Route::get('/my-consultations', [ConsultationController::class, 'myConsultations']);
    Route::post('/consultations/{id}/complete', [ConsultationController::class, 'complete']);
    
    // Ambulance routes
    Route::apiResource('ambulances', AmbulanceController::class);
    Route::post('/ambulances/{id}/update-location', [AmbulanceController::class, 'updateLocation']);
});
