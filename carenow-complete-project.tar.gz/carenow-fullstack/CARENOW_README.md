# CareNow - Smart Medical Emergency Platform

## نظرة عامة (Overview)

CareNow هو منصة طبية ذكية مصممة لتخزين الملفات الطبية الشاملة للمستخدمين وتوفير نظام طوارئ فوري يربط المرضى بأقرب سيارة إسعاف. كما تتيح المنصة للمرضى التواصل مع الأطباء المتخصصين عبر الإنترنت.

CareNow is a smart medical platform designed to store users' comprehensive medical profiles and provide an instant emergency system connecting patients with the nearest ambulance. The platform also enables patients to communicate with specialized doctors online.

## المميزات الرئيسية (Core Features)

### 1. نظام التنبيه الطارئ (Emergency Alert System)
- زر طوارئ بضغطة واحدة يرسل تنبيهًا فوريًا لأقرب سيارة إسعاف
- تحديد الموقع الجغرافي التلقائي (GPS)
- إرسال الملف الطبي الكامل للمريض إلى الإسعاف
- تتبع حالة الإسعاف في الوقت الفعلي

### 2. إدارة الملف الطبي (Medical Profile Management)
- تخزين شامل لفصيلة الدم، العمر، التاريخ المرضي
- قائمة الحساسية والأدوية الحساسة
- الأدوية الحالية والأمراض المزمنة
- معلومات الاتصال في حالات الطوارئ
- بيانات التأمين الصحي

### 3. الاستشارات الطبية عبر الإنترنت (Online Consultations)
- حجز مواعيد مع أطباء متخصصين
- استشارات عبر الإنترنت أو شخصية
- نظام مراسلة آمن بين المريض والطبيب
- إصدار الوصفات الطبية إلكترونيًا
- تقييم الأطباء

### 4. نظام إدارة الإسعاف (Ambulance Management)
- تتبع موقع سيارات الإسعاف في الوقت الفعلي
- خوارزمية ذكية لإيجاد أقرب إسعاف متاح
- حساب المسافة والوقت المتوقع للوصول
- تحديث حالة الإسعاف (متاح، مشغول، غير متصل)

### 5. لوحة التحكم (Dashboard)
- لوحة تحكم للمرضى لإدارة ملفاتهم ومواعيدهم
- لوحة تحكم للأطباء لإدارة الاستشارات والمرضى
- لوحة تحكم للإدارة لمراقبة النظام
- لوحة تحكم لسائقي الإسعاف لتلقي التنبيهات

## التقنيات المستخدمة (Technology Stack)

### Backend (الخلفية)
- **Framework**: Laravel 10.x (PHP 8.1)
- **Database**: SQLite (للتطوير) / MySQL (للإنتاج)
- **Authentication**: Laravel Sanctum
- **API**: RESTful API

### Frontend (الواجهة)
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **UI Library**: shadcn/ui + Radix UI
- **Styling**: Tailwind CSS + Bootstrap
- **Routing**: React Router v6
- **State Management**: TanStack Query

## هيكل قاعدة البيانات (Database Schema)

### الجداول الرئيسية:

1. **users** - حسابات المستخدمين
   - الاسم، البريد الإلكتروني، كلمة المرور
   - رقم الهاتف، الدور (مريض، طبيب، إداري، سائق إسعاف)

2. **medical_profiles** - الملفات الطبية
   - فصيلة الدم، تاريخ الميلاد، الجنس
   - الطول، الوزن
   - الأمراض المزمنة، الحساسية، الأدوية الحالية
   - معلومات الاتصال في حالات الطوارئ
   - بيانات التأمين

3. **doctors** - ملفات الأطباء
   - التخصص، رقم الترخيص
   - سنوات الخبرة، عنوان العيادة
   - رسوم الاستشارة، أيام وساعات العمل
   - السيرة الذاتية، التقييم

4. **ambulances** - سيارات الإسعاف
   - رقم المركبة، السائق
   - الموقع الحالي (خط العرض والطول)
   - الحالة (متاح، مشغول، غير متصل)
   - نوع المركبة، قائمة المعدات

5. **emergency_alerts** - تنبيهات الطوارئ
   - المستخدم، الموقع، العنوان
   - الحالة (معلق، تم الإرسال، وصل، مكتمل، ملغي)
   - الإسعاف المخصص
   - أوقات الإرسال والوصول والإكمال
   - ملاحظات

6. **consultations** - الاستشارات الطبية
   - المريض، الطبيب
   - تاريخ ووقت الموعد
   - الحالة، نوع الاستشارة
   - الأعراض، التشخيص، الوصفة الطبية
   - رابط الاجتماع (للاستشارات عبر الإنترنت)

7. **messages** - الرسائل
8. **prescriptions** - الوصفات الطبية
9. **reviews** - التقييمات
10. **notifications** - الإشعارات

## التثبيت والتشغيل (Installation)

### متطلبات النظام:
- PHP 8.1 أو أحدث
- Composer
- Node.js 18+ و npm
- SQLite أو MySQL

### تثبيت Backend:

```bash
cd carenow-fullstack

# تثبيت اعتماديات PHP
composer install

# نسخ ملف البيئة
cp .env.example .env

# توليد مفتاح التطبيق
php artisan key:generate

# تشغيل migrations
php artisan migrate

# تشغيل الخادم
php artisan serve
```

الـ API سيكون متاحًا على: `http://localhost:8000`

### تثبيت Frontend:

```bash
# تثبيت اعتماديات Node
npm install

# تشغيل خادم التطوير
npm run dev
```

الواجهة ستكون متاحة على: `http://localhost:5173`

## نقاط النهاية API (API Endpoints)

### المصادقة (Authentication)
- `POST /api/register` - تسجيل مستخدم جديد
- `POST /api/login` - تسجيل الدخول
- `POST /api/logout` - تسجيل الخروج
- `GET /api/me` - الحصول على بيانات المستخدم الحالي

### تنبيهات الطوارئ (Emergency Alerts)
- `GET /api/emergency-alerts` - قائمة جميع التنبيهات
- `POST /api/emergency-alerts` - إنشاء تنبيه طوارئ
- `GET /api/emergency-alerts/{id}` - تفاصيل التنبيه
- `PUT /api/emergency-alerts/{id}` - تحديث حالة التنبيه

### الملفات الطبية (Medical Profiles)
- `GET /api/medical-profiles` - قائمة الملفات
- `POST /api/medical-profiles` - إنشاء ملف طبي
- `GET /api/my-profile` - الحصول على ملفي الطبي
- `PUT /api/medical-profiles/{id}` - تحديث الملف

### الأطباء (Doctors)
- `GET /api/doctors` - قائمة الأطباء
- `GET /api/doctors-available` - الأطباء المتاحون
- `GET /api/doctors/{id}` - تفاصيل الطبيب

### الاستشارات (Consultations)
- `GET /api/consultations` - قائمة الاستشارات
- `POST /api/consultations` - حجز استشارة
- `GET /api/my-consultations` - استشاراتي
- `POST /api/consultations/{id}/complete` - إكمال الاستشارة

## سير عمل نظام الطوارئ (Emergency Flow)

1. المريض يضغط على زر الطوارئ
2. النظام يلتقط موقع GPS للمريض
3. النظام يسترجع الملف الطبي الكامل للمريض
4. الخوارزمية تجد أقرب إسعاف متاح
5. يتم إرسال التنبيه إلى سائق الإسعاف
6. السائق يتلقى إشعارًا مع موقع المريض والمعلومات الطبية
7. السائق يحدث الحالة (تم الإرسال → وصل → مكتمل)
8. المريض يتلقى تحديثات في الوقت الفعلي

## الأمان (Security)

- تشفير كلمات المرور باستخدام bcrypt
- مصادقة API باستخدام Laravel Sanctum tokens
- حماية CORS
- منع SQL injection عبر Eloquent ORM
- حماية XSS
- التحقق من CSRF token

## الوثائق التقنية (Technical Documentation)

### مخطط ERD (Entity Relationship Diagram)
تم إنشاء مخطط ERD كامل يوضح العلاقات بين جميع الجداول في قاعدة البيانات.

### مخطط Use Case
يوضح التفاعلات بين المستخدمين المختلفين والنظام.

### تصميم النظام (System Design)
- معمارية RESTful API
- فصل Frontend عن Backend
- استخدام Token-based authentication
- تصميم قاعدة بيانات محسّن مع Indexes

## الميزات المستقبلية (Future Enhancements)

- [ ] دعم الإشعارات الفورية (Push Notifications)
- [ ] تكامل مع خرائط Google لتتبع الإسعاف
- [ ] مكالمات فيديو للاستشارات عبر الإنترنت
- [ ] تطبيق موبايل (iOS & Android)
- [ ] نظام دفع إلكتروني
- [ ] تقارير وإحصائيات متقدمة
- [ ] دعم متعدد اللغات

## الفريق (Team)

تم تطوير هذا المشروع كجزء من مشروع أكاديمي.

## الترخيص (License)

هذا المشروع مطور لأغراض تعليمية.

---

**CareNow** - صحتك، أولويتنا 🏥
**CareNow** - Your Health, Our Priority 🏥
