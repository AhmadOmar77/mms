import { Shield, Phone, Video, FileText, MapPin, Bell, Clock, Users } from "lucide-react";

const features = [
  {
    icon: FileText,
    title: "Complete Medical Profile",
    description: "Store your blood type, allergies, medications, and medical history in one secure place.",
    color: "primary",
  },
  {
    icon: Phone,
    title: "One-Tap Emergency",
    description: "Instantly alert the nearest ambulance with your location and medical information.",
    color: "emergency",
  },
  {
    icon: Video,
    title: "Doctor Consultations",
    description: "Connect with specialized doctors online for follow-ups and non-emergency care.",
    color: "accent",
  },
  {
    icon: MapPin,
    title: "GPS Location Sharing",
    description: "Automatic location sharing ensures responders find you quickly in emergencies.",
    color: "success",
  },
  {
    icon: Bell,
    title: "Smart Notifications",
    description: "Receive real-time updates on ambulance ETA and emergency response status.",
    color: "primary",
  },
  {
    icon: Users,
    title: "Family Accounts",
    description: "Manage medical profiles for your entire family under one account.",
    color: "accent",
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-20 md:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-muted/30 to-transparent" />
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
            <Shield className="w-4 h-4" />
            Comprehensive Care
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Everything You Need in
            <br />
            <span className="text-gradient">One Platform</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            CareNow combines emergency response with complete medical profile management 
            to ensure you get the right care, fast.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group relative bg-card rounded-2xl p-6 md:p-8 shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 border border-border/50"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Icon */}
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-5 transition-transform group-hover:scale-110 ${
                feature.color === 'primary' ? 'bg-primary/10 text-primary' :
                feature.color === 'emergency' ? 'bg-emergency/10 text-emergency' :
                feature.color === 'accent' ? 'bg-accent/10 text-accent' :
                'bg-success/10 text-success'
              }`}>
                <feature.icon className="w-7 h-7" />
              </div>
              
              {/* Content */}
              <h3 className="text-xl font-bold mb-3 text-foreground group-hover:text-primary transition-colors">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Effect */}
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                feature.color === 'primary' ? 'bg-primary/5' :
                feature.color === 'emergency' ? 'bg-emergency/5' :
                feature.color === 'accent' ? 'bg-accent/5' :
                'bg-success/5'
              }`} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
