import { Button } from "@/components/ui/button";
import { Phone, MapPin, Shield, ArrowRight } from "lucide-react";

const EmergencyBanner = () => {
  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-emergency opacity-95" />
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
        backgroundSize: '32px 32px'
      }} />
      
      {/* Animated Circles */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="w-[400px] h-[400px] border border-emergency-foreground/20 rounded-full animate-pulse-slow" />
        <div className="absolute inset-4 border border-emergency-foreground/15 rounded-full animate-pulse-slow" style={{ animationDelay: '0.5s' }} />
        <div className="absolute inset-8 border border-emergency-foreground/10 rounded-full animate-pulse-slow" style={{ animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-emergency-foreground/20 backdrop-blur-sm rounded-full text-emergency-foreground text-sm font-medium mb-6">
            <Shield className="w-4 h-4" />
            Emergency Response System
          </div>

          {/* Heading */}
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-emergency-foreground mb-6">
            Every Second Counts
            <br />
            In An Emergency
          </h2>
          
          <p className="text-lg md:text-xl text-emergency-foreground/80 mb-8 max-w-2xl mx-auto">
            With CareNow, help is just one tap away. Your medical profile is instantly 
            shared with responders so they can provide the right care immediately.
          </p>

          {/* Features */}
          <div className="flex flex-wrap justify-center gap-6 mb-10">
            <div className="flex items-center gap-2 text-emergency-foreground">
              <MapPin className="w-5 h-5" />
              <span className="font-medium">GPS Location</span>
            </div>
            <div className="flex items-center gap-2 text-emergency-foreground">
              <Phone className="w-5 h-5" />
              <span className="font-medium">Instant Alert</span>
            </div>
            <div className="flex items-center gap-2 text-emergency-foreground">
              <Shield className="w-5 h-5" />
              <span className="font-medium">Medical Profile</span>
            </div>
          </div>

          {/* CTA */}
          <Button 
            variant="glass" 
            size="xl" 
            className="bg-emergency-foreground text-emergency hover:bg-emergency-foreground/90 shadow-lg group"
          >
            <Phone className="w-5 h-5 animate-heartbeat" />
            Activate Emergency Alert
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default EmergencyBanner;
