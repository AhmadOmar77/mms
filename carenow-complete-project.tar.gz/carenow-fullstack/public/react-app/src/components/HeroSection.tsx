import { Button } from "@/components/ui/button";
import { Phone, Shield, Clock, ArrowRight } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
      <div className="absolute top-20 right-0 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-accent/10 rounded-full blur-3xl" />
      
      {/* Grid Pattern */}
      <div className="absolute inset-0 opacity-[0.02]" style={{
        backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
        backgroundSize: '40px 40px'
      }} />

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-6 animate-fade-up" style={{ animationDelay: '0.1s' }}>
              <Shield className="w-4 h-4" />
              Your Health, Our Priority
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 animate-fade-up" style={{ animationDelay: '0.2s' }}>
              Emergency Care
              <br />
              <span className="text-gradient">When Seconds Matter</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0 animate-fade-up" style={{ animationDelay: '0.3s' }}>
              CareNow connects you instantly to the nearest ambulance with your complete medical profile. 
              One tap can save a life.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12 animate-fade-up" style={{ animationDelay: '0.4s' }}>
              <Button variant="emergency" size="xl" className="group">
                <Phone className="w-5 h-5 animate-heartbeat" />
                Emergency Alert
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button variant="hero-outline" size="xl">
                Create Profile
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 animate-fade-up" style={{ animationDelay: '0.5s' }}>
              <div className="text-center lg:text-left">
                <div className="text-2xl md:text-3xl font-bold text-primary">30s</div>
                <div className="text-sm text-muted-foreground">Avg Response</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl md:text-3xl font-bold text-primary">50k+</div>
                <div className="text-sm text-muted-foreground">Lives Saved</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl md:text-3xl font-bold text-primary">24/7</div>
                <div className="text-sm text-muted-foreground">Available</div>
              </div>
            </div>
          </div>

          {/* Hero Visual */}
          <div className="relative animate-fade-up" style={{ animationDelay: '0.3s' }}>
            <div className="relative">
              {/* Phone Mockup */}
              <div className="relative mx-auto w-[280px] md:w-[320px] animate-float">
                <div className="bg-foreground rounded-[40px] p-2 shadow-2xl">
                  <div className="bg-card rounded-[32px] overflow-hidden">
                    {/* Status Bar */}
                    <div className="bg-primary/10 px-6 py-3 flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">9:41</span>
                      <div className="flex gap-1">
                        <div className="w-4 h-2 bg-muted-foreground/30 rounded-sm" />
                        <div className="w-4 h-2 bg-muted-foreground/30 rounded-sm" />
                        <div className="w-6 h-3 bg-success rounded-sm" />
                      </div>
                    </div>
                    
                    {/* App Content */}
                    <div className="p-6 space-y-4">
                      <div className="text-center">
                        <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-3">
                          <Shield className="w-8 h-8 text-primary" />
                        </div>
                        <h3 className="font-bold text-foreground">CareNow</h3>
                        <p className="text-xs text-muted-foreground">Your Medical Profile</p>
                      </div>
                      
                      {/* Profile Card */}
                      <div className="bg-muted/50 rounded-xl p-4 space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-primary/20" />
                          <div>
                            <div className="font-medium text-sm">John Doe</div>
                            <div className="text-xs text-muted-foreground">Blood Type: O+</div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="bg-card rounded-lg p-2">
                            <div className="text-muted-foreground">Age</div>
                            <div className="font-semibold">32 years</div>
                          </div>
                          <div className="bg-card rounded-lg p-2">
                            <div className="text-muted-foreground">Allergies</div>
                            <div className="font-semibold">Penicillin</div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Emergency Button Preview */}
                      <div className="bg-gradient-emergency text-emergency-foreground rounded-xl p-4 text-center shadow-emergency">
                        <Phone className="w-6 h-6 mx-auto mb-1" />
                        <div className="text-sm font-bold">Emergency Alert</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Floating Elements */}
                <div className="absolute -right-4 top-1/4 bg-card rounded-xl p-3 shadow-card animate-float" style={{ animationDelay: '0.5s' }}>
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium">ETA: 3 min</span>
                  </div>
                </div>
                
                <div className="absolute -left-4 bottom-1/3 bg-success/10 border border-success/30 rounded-xl p-3 shadow-card animate-float" style={{ animationDelay: '1s' }}>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
                    <span className="text-sm font-medium text-success">Ambulance Dispatched</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
