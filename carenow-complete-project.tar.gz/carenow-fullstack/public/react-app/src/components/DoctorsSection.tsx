import { Button } from "@/components/ui/button";
import { Star, Video, Calendar, ArrowRight } from "lucide-react";

const doctors = [
  {
    name: "Dr. Sarah Mitchell",
    specialty: "Emergency Medicine",
    rating: 4.9,
    reviews: 128,
    available: true,
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&h=300&fit=crop&crop=face",
  },
  {
    name: "Dr. James Chen",
    specialty: "Cardiology",
    rating: 4.8,
    reviews: 96,
    available: true,
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300&h=300&fit=crop&crop=face",
  },
  {
    name: "Dr. Emily Roberts",
    specialty: "General Practice",
    rating: 4.9,
    reviews: 215,
    available: false,
    image: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=300&h=300&fit=crop&crop=face",
  },
  {
    name: "Dr. Michael Thompson",
    specialty: "Internal Medicine",
    rating: 4.7,
    reviews: 84,
    available: true,
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&h=300&fit=crop&crop=face",
  },
];

const DoctorsSection = () => {
  return (
    <section id="doctors" className="py-20 md:py-32 relative bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
              <Video className="w-4 h-4" />
              Online Consultations
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Meet Our <span className="text-gradient">Expert Doctors</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Connect with certified healthcare professionals for non-emergency consultations 
              and follow-ups from the comfort of your home.
            </p>
          </div>
          <Button variant="outline" className="self-start md:self-auto">
            View All Doctors
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Doctors Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {doctors.map((doctor, index) => (
            <div
              key={doctor.name}
              className="group bg-card rounded-2xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300 border border-border/50"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {/* Availability Badge */}
                <div className={`absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-medium ${
                  doctor.available 
                    ? 'bg-success/90 text-success-foreground' 
                    : 'bg-muted/90 text-muted-foreground'
                }`}>
                  {doctor.available ? 'Available' : 'Busy'}
                </div>
              </div>
              
              {/* Content */}
              <div className="p-5">
                <h3 className="text-lg font-bold text-foreground mb-1">
                  {doctor.name}
                </h3>
                <p className="text-sm text-primary font-medium mb-3">
                  {doctor.specialty}
                </p>
                
                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-accent text-accent" />
                    <span className="font-semibold text-sm">{doctor.rating}</span>
                  </div>
                  <span className="text-muted-foreground text-sm">
                    ({doctor.reviews} reviews)
                  </span>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button 
                    variant={doctor.available ? "default" : "secondary"} 
                    size="sm" 
                    className="flex-1"
                    disabled={!doctor.available}
                  >
                    <Video className="w-4 h-4 mr-1" />
                    Consult
                  </Button>
                  <Button variant="outline" size="sm">
                    <Calendar className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DoctorsSection;
