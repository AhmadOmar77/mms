import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import DoctorsSection from "@/components/DoctorsSection";
import EmergencyBanner from "@/components/EmergencyBanner";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <DoctorsSection />
      <EmergencyBanner />
      <Footer />
    </main>
  );
};

export default Index;
