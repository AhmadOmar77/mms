# CareNow System Design Document

## 1. System Overview

CareNow is a full-stack web application designed to revolutionize emergency medical response and facilitate online healthcare consultations. The system employs a modern architecture separating frontend and backend concerns while maintaining seamless integration through RESTful APIs.

## 2. Architecture

### 2.1 High-Level Architecture

The system follows a **three-tier architecture**:

1. **Presentation Layer** (Frontend)
   - React-based single-page application
   - Responsive design using Tailwind CSS and Bootstrap
   - Client-side routing with React Router
   - State management with TanStack Query

2. **Application Layer** (Backend API)
   - Laravel RESTful API
   - Business logic implementation
   - Authentication and authorization
   - Data validation and processing

3. **Data Layer** (Database)
   - SQLite for development
   - MySQL for production
   - Relational database with normalized schema
   - Foreign key constraints for data integrity

### 2.2 System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (React)                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │  Login   │  │Dashboard │  │Emergency │  │Doctors   │   │
│  │ Register │  │  Profile │  │  Alert   │  │Consult   │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│                         │                                    │
│                    React Router                              │
│                         │                                    │
│                   API Client (Fetch)                         │
└─────────────────────────┼───────────────────────────────────┘
                          │ HTTPS/JSON
                          │
┌─────────────────────────▼───────────────────────────────────┐
│                   Backend API (Laravel)                      │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              API Routes (routes/api.php)              │  │
│  └────────────────────┬─────────────────────────────────┘  │
│                       │                                      │
│  ┌────────────────────▼─────────────────────────────────┐  │
│  │           Controllers (Business Logic)                │  │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐       │  │
│  │  │  Auth  │ │Medical │ │Emergency│ │Consult │       │  │
│  │  └────────┘ └────────┘ └────────┘ └────────┘       │  │
│  └────────────────────┬─────────────────────────────────┘  │
│                       │                                      │
│  ┌────────────────────▼─────────────────────────────────┐  │
│  │              Models (Eloquent ORM)                    │  │
│  │  User, Doctor, Patient, Ambulance, EmergencyAlert    │  │
│  └────────────────────┬─────────────────────────────────┘  │
│                       │                                      │
│                Laravel Sanctum (Authentication)              │
└───────────────────────┼──────────────────────────────────────┘
                        │
┌───────────────────────▼──────────────────────────────────────┐
│                    Database (MySQL/SQLite)                    │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐    │
│  │Users │ │Doctors│ │Medical│ │Ambulan│ │Emergency│ │Consult│ │
│  │      │ │       │ │Profile│ │  ces  │ │ Alerts  │ │ations │ │
│  └──────┘ └──────┘ └──────┘ └──────┘ └──────┘ └──────┘    │
└──────────────────────────────────────────────────────────────┘
```

## 3. Core Components

### 3.1 Authentication System

**Technology**: Laravel Sanctum (Token-based authentication)

**Flow**:
1. User submits credentials (email, password)
2. Backend validates credentials
3. System generates API token
4. Token stored in localStorage on client
5. Token included in Authorization header for subsequent requests
6. Backend validates token on each protected route

**Security Measures**:
- Password hashing with bcrypt (cost factor: 10)
- Token expiration and rotation
- HTTPS-only communication in production
- CSRF protection for state-changing operations

### 3.2 Emergency Alert System

**Core Algorithm**: Nearest Ambulance Dispatch

```
function findNearestAmbulance(userLat, userLng):
    availableAmbulances = Ambulance.where(status = 'available')
                                   .whereNotNull(current_latitude)
                                   .whereNotNull(current_longitude)
                                   .get()
    
    if availableAmbulances.isEmpty():
        return null
    
    nearestAmbulance = null
    minDistance = INFINITY
    
    for ambulance in availableAmbulances:
        distance = calculateHaversineDistance(
            userLat, userLng,
            ambulance.latitude, ambulance.longitude
        )
        
        if distance < minDistance:
            minDistance = distance
            nearestAmbulance = ambulance
    
    return nearestAmbulance
```

**Haversine Distance Formula**:
```
function calculateHaversineDistance(lat1, lon1, lat2, lon2):
    R = 6371  // Earth radius in kilometers
    
    dLat = deg2rad(lat2 - lat1)
    dLon = deg2rad(lon2 - lon1)
    
    a = sin(dLat/2)² + cos(lat1) * cos(lat2) * sin(dLon/2)²
    c = 2 * atan2(√a, √(1-a))
    
    distance = R * c
    return distance
```

**Emergency Alert Workflow**:
1. Patient presses emergency button
2. Frontend captures GPS coordinates using Geolocation API
3. API request sent to `/api/emergency-alerts` with location
4. Backend retrieves patient's medical profile
5. System finds nearest available ambulance
6. Alert created with status "dispatched"
7. Ambulance status updated to "busy"
8. Notification sent to ambulance driver
9. Driver receives patient location and medical info
10. Driver updates status through mobile interface
11. Patient receives real-time status updates

### 3.3 Medical Profile Management

**Data Structure**:
```json
{
  "user_id": 1,
  "blood_type": "O+",
  "date_of_birth": "1990-01-15",
  "gender": "male",
  "height": 175,
  "weight": 70,
  "chronic_diseases": ["Diabetes Type 2", "Hypertension"],
  "allergies": ["Penicillin", "Peanuts"],
  "current_medications": [
    "Metformin 500mg - 2x daily",
    "Lisinopril 10mg - 1x daily"
  ],
  "emergency_contact_name": "Jane Doe",
  "emergency_contact_phone": "+1234567890",
  "insurance_number": "INS123456",
  "insurance_provider": "HealthCare Plus"
}
```

**Access Control**:
- Patients: Full CRUD on their own profile
- Doctors: Read-only access during consultations
- Ambulance Drivers: Read-only access during emergencies
- Admins: Full access to all profiles

### 3.4 Doctor Consultation System

**Consultation Flow**:

```
┌─────────┐         ┌─────────┐         ┌─────────┐
│ Patient │         │ System  │         │ Doctor  │
└────┬────┘         └────┬────┘         └────┬────┘
     │                   │                   │
     │ Browse Doctors    │                   │
     ├──────────────────>│                   │
     │                   │                   │
     │ Doctor List       │                   │
     │<──────────────────┤                   │
     │                   │                   │
     │ Book Consultation │                   │
     ├──────────────────>│                   │
     │                   │                   │
     │                   │ Notify Doctor     │
     │                   ├──────────────────>│
     │                   │                   │
     │ Confirmation      │                   │
     │<──────────────────┤                   │
     │                   │                   │
     │ Join Consultation │                   │
     ├──────────────────>│<──────────────────┤
     │                   │                   │
     │ Chat/Video Call   │                   │
     │<─────────────────────────────────────>│
     │                   │                   │
     │                   │ Issue Prescription│
     │                   │<──────────────────┤
     │                   │                   │
     │ Receive Prescription                  │
     │<──────────────────┤                   │
     │                   │                   │
     │ Rate & Review     │                   │
     ├──────────────────>│                   │
     │                   │                   │
```

**Consultation States**:
- `scheduled`: Appointment booked, awaiting consultation
- `in_progress`: Consultation currently happening
- `completed`: Consultation finished, prescription issued
- `cancelled`: Cancelled by patient or doctor
- `no_show`: Patient didn't attend scheduled appointment

## 4. Database Design

### 4.1 Key Relationships

1. **One-to-One**:
   - User → MedicalProfile
   - User → Doctor (for doctor users)

2. **One-to-Many**:
   - User → EmergencyAlerts
   - User → Consultations (as patient)
   - Doctor → Consultations
   - Ambulance → EmergencyAlerts
   - Consultation → Messages
   - Consultation → Prescriptions

3. **Many-to-Many**:
   - None in current design (can be extended for doctor specializations)

### 4.2 Indexing Strategy

**Primary Indexes**:
- All tables have auto-incrementing `id` as primary key

**Foreign Key Indexes**:
- Automatically created on all foreign key columns

**Performance Indexes**:
```sql
-- Emergency alerts by status for quick filtering
CREATE INDEX idx_emergency_alerts_status ON emergency_alerts(status);

-- Consultations by date for appointment scheduling
CREATE INDEX idx_consultations_date ON consultations(appointment_date, status);

-- Ambulances by status and location for dispatch
CREATE INDEX idx_ambulances_status_location 
ON ambulances(status, current_latitude, current_longitude);

-- Notifications by user and read status
CREATE INDEX idx_notifications_user_read 
ON notifications(user_id, is_read);
```

### 4.3 Data Integrity Constraints

1. **Foreign Key Constraints**: ON DELETE CASCADE for dependent records
2. **Unique Constraints**: Email, license numbers, vehicle numbers
3. **Check Constraints**: Enum values for status fields
4. **NOT NULL Constraints**: Required fields like user_id, blood_type

## 5. API Design

### 5.1 RESTful Principles

- **Resource-based URLs**: `/api/doctors`, `/api/emergency-alerts`
- **HTTP Methods**: GET (read), POST (create), PUT/PATCH (update), DELETE (remove)
- **Status Codes**: 200 (success), 201 (created), 400 (bad request), 401 (unauthorized), 404 (not found), 422 (validation error), 500 (server error)
- **JSON Format**: All requests and responses use JSON

### 5.2 Response Format

**Success Response**:
```json
{
  "success": true,
  "message": "Operation successful",
  "data": {
    // Resource data
  }
}
```

**Error Response**:
```json
{
  "success": false,
  "message": "Error message",
  "errors": {
    "field": ["Validation error message"]
  }
}
```

### 5.3 Authentication

All protected routes require Bearer token:
```
Authorization: Bearer {token}
```

## 6. Security Considerations

### 6.1 Authentication & Authorization
- Token-based authentication with Laravel Sanctum
- Role-based access control (RBAC)
- Token expiration and refresh mechanism

### 6.2 Data Protection
- Password hashing with bcrypt
- Sensitive data encryption at rest
- HTTPS for data in transit
- SQL injection prevention via Eloquent ORM
- XSS protection through React's built-in escaping

### 6.3 API Security
- CORS configuration for allowed origins
- Rate limiting to prevent abuse
- Input validation and sanitization
- CSRF token validation

### 6.4 Privacy
- GDPR compliance considerations
- Medical data access logging
- User consent management
- Data retention policies

## 7. Performance Optimization

### 7.1 Database Optimization
- Proper indexing on frequently queried columns
- Query optimization using Eloquent eager loading
- Database connection pooling
- Caching frequently accessed data

### 7.2 Frontend Optimization
- Code splitting and lazy loading
- Image optimization
- Browser caching
- Minification and bundling with Vite

### 7.3 API Optimization
- Pagination for large datasets
- Response compression (gzip)
- API caching with Redis (future enhancement)
- Asynchronous job processing for heavy tasks

## 8. Scalability

### 8.1 Horizontal Scaling
- Stateless API design allows multiple server instances
- Load balancing across API servers
- Database read replicas for read-heavy operations

### 8.2 Vertical Scaling
- Database optimization and indexing
- Server resource allocation
- Caching layer implementation

### 8.3 Future Enhancements
- Microservices architecture for specific modules
- Message queue for asynchronous processing
- CDN for static assets
- Real-time features with WebSockets

## 9. Monitoring & Logging

### 9.1 Application Logging
- Laravel logging for errors and exceptions
- API request/response logging
- User activity tracking
- Emergency alert audit trail

### 9.2 Performance Monitoring
- Response time tracking
- Database query performance
- API endpoint usage statistics
- Error rate monitoring

### 9.3 Health Checks
- Database connectivity
- API availability
- External service dependencies

## 10. Deployment Strategy

### 10.1 Development Environment
- Local development with SQLite
- Hot module replacement for frontend
- Laravel development server

### 10.2 Production Environment
- MySQL database
- Nginx web server
- PHP-FPM for Laravel
- Static file serving for React build
- SSL/TLS certificates
- Environment-based configuration

### 10.3 CI/CD Pipeline (Recommended)
1. Code commit to repository
2. Automated testing
3. Build frontend assets
4. Database migrations
5. Deploy to staging
6. Manual approval
7. Deploy to production

## 11. Testing Strategy

### 11.1 Backend Testing
- Unit tests for models and business logic
- Feature tests for API endpoints
- Integration tests for database operations

### 11.2 Frontend Testing
- Component unit tests
- Integration tests for user flows
- End-to-end testing with Cypress

### 11.3 Manual Testing
- User acceptance testing (UAT)
- Security testing
- Performance testing
- Cross-browser compatibility

## 12. Conclusion

The CareNow system is designed with modern web development best practices, focusing on scalability, security, and user experience. The architecture supports future enhancements while maintaining code quality and system reliability. The separation of concerns between frontend and backend allows independent scaling and development of each layer.

---

**Document Version**: 1.0  
**Last Updated**: December 9, 2025  
**Author**: CareNow Development Team
